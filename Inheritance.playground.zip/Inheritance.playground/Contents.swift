///
/// Базовый класс
///

class Animal {
    func hunting() {
        print("Я охочусь\n")
    }
}

// Сами по себе экземпляры базового класса зачастую не используются,
// и пример ниже не показывает никакой конкретики
let someAnimal = Animal()
print("— Animal:")
someAnimal.hunting()

///
/// Птица тоже животное
///

class Bird: Animal {
    var legsCount: Int {
        return 2
    }
    
    override func hunting() {
        print("Летаю и ищу добычу\n")
    }
}

let eagle = Bird()
print("— Eagle:")
print("Сколько ног: ", eagle.legsCount)
eagle.hunting()

///
/// Пример странной птицы (Пингвин):
///

class Penguin: Bird {
    override func hunting() {
        print("Прыгаю в воду, плаваю и ищу добычу\n")
    }
}

let arcticPenguin = Penguin()
print("— Arctic penguin:")
print("Сколько ног: ", arcticPenguin.legsCount)
arcticPenguin.hunting()

///
/// Выше были рассмотрено наследование классов на примере наследования видов животных
///
/// Теперь рассмотрим более гибкие примеры переопределения методов. На примере млекопитающих
/// 

class Mammal {
    var canFly: Bool {
        return false
    }
    
    func giveOffspring() {
        print("Даю потомство\n")
    }
}

///
/// Перейдем сразу к конкретному млекопиющему
///

class Monkey: Mammal {
    var legsCount: Int {
        return 4
    }
    
    override func giveOffspring() {
        print("Рожаю детенышей")
    }
}

///
/// Пример с использованием логики из класса предка + добавление собственной
///

class Human: Monkey {
    var childrenCount: Int = 0
    
    override var legsCount: Int {
        return 2
    }
    
    override func giveOffspring() {
        super.giveOffspring()
        raiseChildren()
    }
    
    private func raiseChildren() {
        print("Воспитываю, отдаю в садик, школу\n")
    }
}

let monkey = Monkey()
print("\n")
print("— Monkey:")
print("Сколько ног: ", monkey.legsCount)
monkey.giveOffspring()

let human = Human()
print("\n— Human:")
print("Сколько ног: ", human.legsCount)
human.giveOffspring()

///
/// Теперь давайте взглянем на все эти примеры еще раз. Среди них есть пример, который не очень хорошо ложится под термин наследование.
/// Как я уже говорил, элементарно понять, стоит ли A наследовать от B, можно задав один вопрос: А является B?
/// Задав такой вопрос относительно человека и обезьяны будет некорректно заявить, что Человек это Обезьяна.
/// Поэтому не стоит человека наследовать от обезьяны, тут еще есть недостающие звенья для такого наследования.
/// Идеальным примером будет унаследовать Австралопитека от Обезьяны. Потому что прямо по википедии это род приматов,
/// и на наш вопрос мы получаем четкий ответ и унаследоать одно от другого будет логично
///

class Australopithecus: Monkey {
    override var legsCount: Int {
        return 2
    }
    
    override func giveOffspring() {
        super.giveOffspring()
        raiseChildren()
    }
    
    private func raiseChildren() {
        print("Воспитываю, учу охотиться и т.д.\n")
    }
}

///
/// Посмотрим еще на один пример переопределения методов
/// Как я уже сказал, вычисляемые свойства это тоже своего рода методы и их можно переопределять.
/// Но в какой-то степени можно переопределять и хранимые свойства,
/// но только добавлением или переопределением обсерверов или геттеров / сеттеров
///

class Women: Human {
    private(set) var isMother: Bool = false
    
    override var childrenCount: Int {
        didSet {
            isMother = childrenCount > 0
        }
    }
}

let women = Women()
print("\n— Women:")
print("Сколько детей: ", women.childrenCount)
print("Она мать? - ", women.isMother)
women.childrenCount = 2
print("Сколько детей: ", women.childrenCount)
print("Она мать? - ", women.isMother)

///
/// Предотвращение переопределений
///

final class Me: Human {
    
}

class Dolphin: Mammal {
    final override var canFly: Bool {
        return false
    }
}
